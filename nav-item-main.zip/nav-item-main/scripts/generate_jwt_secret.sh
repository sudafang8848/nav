#!/usr/bin/env bash
# 生成一个强随机 JWT_SECRET，用法：
# ./scripts/generate_jwt_secret.sh

set -euo pipefail

if command -v openssl >/dev/null 2>&1; then
  openssl rand -base64 48
else
  # fallback to python3
  python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(48))
PY
fi
