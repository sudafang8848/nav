部署说明（用于在 VPS 上通过 Nginx 反向代理和 Docker 运行）

前提
- VPS 已安装 Docker 与 docker compose
- 已将本仓库上传到 VPS 并在项目根（含 `Dockerfile` 与 `docker-compose.yml`）
- 你拥有域名 `nav.ctyh777.ggff.net` 已解析到该 VPS 的公网 IP

快速部署步骤

1. 在项目根复制并编辑 `.env`（务必更改密码与 JWT_SECRET）：

```bash
cp .env.example .env
# 编辑 .env，修改 ADMIN_PASSWORD 和 JWT_SECRET
```

2. 构建并启动容器：

```bash
docker compose up -d --build
```

3. 在 VPS 上安装并配置 Nginx（以下在 Ubuntu 上示例）：

```bash
sudo apt update; sudo apt install -y nginx certbot python3-certbot-nginx
# 把项目中的 nginx 配置示例复制到 Nginx 配置目录
sudo cp deploy/nginx/nav-item.conf /etc/nginx/sites-available/nav-item
sudo ln -s /etc/nginx/sites-available/nav-item /etc/nginx/sites-enabled/nav-item
sudo nginx -t
sudo systemctl reload nginx
```

4. 使用 Certbot 获取证书（替换为你的域名）：

```bash
sudo certbot --nginx -d nav.ctyh777.ggff.net
```

长期建议
- 确保 `.env` 中的 `ADMIN_PASSWORD` 与 `JWT_SECRET` 为强随机值。
- 使用 `docker compose logs -f` 检查启动日志；若进程在生产模式退出，说明配置不满足安全检查（请按提示设置环境变量）。
- 将 `database` 与 `uploads` 目录设为合适权限（保证容器能写入）。
 
生产部署（使用 `docker-compose.prod.yml`）

1. 生成强随机 `JWT_SECRET`：

```bash
# 使用 openssl
openssl rand -base64 48

# 或使用仓库附带脚本（在 VPS 上运行）
./scripts/generate_jwt_secret.sh > .env.JWT_SECRET
```

2. 将密钥写入 `.env`：

```bash
cp .env.example .env
# 编辑 .env，设置 ADMIN_PASSWORD 与 JWT_SECRET（可从上一步复制）
```

3. 启动生产 compose（包含 nginx 反向代理）：

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

注意：`docker-compose.prod.yml` 使用容器内的 `nginx` 来反向代理到 `nav-item` 服务。建议在生产环境下，证书（TLS）由宿主机上的 Certbot 管理并将证书文件挂载到 `./deploy/nginx/ssl`，或者使用专门的 Let's Encrypt companion 容器来自动签发证书。
